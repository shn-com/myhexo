### 关于我
从事 WEB 开发，主要开发语言 `PHP`，熟悉使用 `Laravel`、`ThinkPHP` 等主流框架；对 `Modern PHP` 情有独钟；有一定的代码洁癖。

对`服务端`、`前端`、`数据分析`等技能有所了解。

热爱`开源项目`、热爱`新技术`、热爱`新事物`。
### 关于工作
城市：`深圳`
### 关于学习
正在往终身学习者前进...
近期学习方向：Python (人工智能)
### 关于座右铭
> The Harder You Work, The Luckier You Will Be. (越努力，越幸运)

### 关于爱好
热爱`运动`，尤其喜爱`羽毛球`、`阅读`、`电影（Top250）`、`旅行`。
### 联系我
* Home: [minhow.com](https://minhow.com)
* Blog: [blog.minhow.com](http://blog.minhow.com)
* Email: huangminhow@gmail.com
* GitHub: [MinHow](https://github.com/WongMinHo)
* WeiBo: [MinHow](http://weibo.com/WongMinHo)
* Twitter: [MinHow](https://twitter.com/huangminhow)
